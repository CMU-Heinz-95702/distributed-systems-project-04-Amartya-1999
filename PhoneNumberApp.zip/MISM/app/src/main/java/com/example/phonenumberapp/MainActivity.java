// Kumar Amartya
// aamartya

package com.example.phonenumberapp;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.widget.*;

import org.json.JSONObject;

import java.io.*;
import java.net.*;

public class MainActivity extends AppCompatActivity {

    // UI components
    EditText phoneInput;
    Button verifyButton;
    TextView resultText;

    // URL to your backend phone verification servlet (hosted on GitHub Codespaces)
    // Uncomment the local URL when testing on emulator locally
    // String BASE_URL = "http://10.0.2.2:8080/PhoneNumberVerification_war_exploded/verify-phone";
    String BASE_URL = "https://didactic-orbit-pw6776v79w4h74qg-8080.app.github.dev/verify-phone";

    // Handler to post updates to the main (UI) thread
    Handler uiHandler = new Handler(Looper.getMainLooper());

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize UI components
        phoneInput = findViewById(R.id.phoneInput);
        verifyButton = findViewById(R.id.verifyButton);
        resultText = findViewById(R.id.resultText);

        // Handle button click
        verifyButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String phone = phoneInput.getText().toString().trim();

                // Validate input
                if (phone.isEmpty()) {
                    resultText.setText("Please enter a phone number.");
                    return;
                }

                resultText.setText("⏳ Verifying...");

                // Run network operation in background thread
                new Thread(() -> {
                    try {
                        // Build the full URL with encoded phone number
                        String fullUrl = BASE_URL + "?phone=" + URLEncoder.encode(phone, "UTF-8");
                        URL url = new URL(fullUrl);
                        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                        conn.setRequestMethod("GET");

                        // Read the response
                        BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream()));
                        StringBuilder response = new StringBuilder();
                        String line;

                        while ((line = reader.readLine()) != null) {
                            response.append(line);
                        }

                        reader.close();

                        // Parse JSON response
                        JSONObject json = new JSONObject(response.toString());
                        boolean valid = json.optBoolean("valid", false);

                        // Prepare result message
                        String result = valid ? "✅ Valid phone number!" : "❌ Invalid phone number.";

                        // Update result text on UI thread
                        uiHandler.post(() -> resultText.setText(result));

                    } catch (Exception e) {
                        e.printStackTrace();
                        // Display error on UI thread
                        uiHandler.post(() -> resultText.setText("Error contacting server: " + e.getMessage()));
                    }
                }).start(); // Start the background thread
            }
        });
    }
}
