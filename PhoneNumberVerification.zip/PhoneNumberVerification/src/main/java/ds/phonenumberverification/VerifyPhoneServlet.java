// Kumar Amartya
// aamartya
package ds.phonenumberverification;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import org.bson.Document;
import org.json.JSONObject;

import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.Date;

import com.mongodb.ConnectionString;
import com.mongodb.MongoClientSettings;
import com.mongodb.ServerApi;
import com.mongodb.ServerApiVersion;
import com.mongodb.client.*;

@WebServlet("/verify-phone")
public class VerifyPhoneServlet extends HttpServlet {

    // API Key for Veriphone
    private final String API_KEY = "932D83992F4C45BE859E25FCFDEC9CB3";

    // Veriphone API endpoint
    private final String VERIPHONE_URL = "https://api.veriphone.io/v2/verify";

    // MongoDB connection details
    private final String MONGO_URI = "mongodb+srv://aamartya:cmumism@androidproject.l70o0.mongodb.net/?retryWrites=true&w=majority&appName=AndroidProject";
    private final String DB_NAME = "phone";
    private final String COLLECTION_NAME = "phonelogs";

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        // Get 'phone' parameter from request
        String phone = req.getParameter("phone");

        // Validate input
        if (phone == null || phone.isEmpty()) {
            resp.setStatus(HttpServletResponse.SC_BAD_REQUEST);
            resp.getWriter().write("{\"error\": \"Phone number is required.\"}");
            return;
        }

        // Encode phone number to safely use in URL
        String encodedPhone = URLEncoder.encode(phone, "UTF-8");
        String apiUrl = VERIPHONE_URL + "?phone=" + encodedPhone + "&key=" + API_KEY;

        // Debug: print the API call being made
        System.out.println("Calling Veriphone API: " + apiUrl);

        // Make GET request to Veriphone
        HttpURLConnection con = (HttpURLConnection) new URL(apiUrl).openConnection();
        con.setRequestMethod("GET");

        int status = con.getResponseCode();
        System.out.println("HTTP Status Code: " + status); // Debug

        InputStream inputStream = (status == 200) ? con.getInputStream() : con.getErrorStream();

        // Read response
        BufferedReader in = new BufferedReader(new InputStreamReader(inputStream));
        StringBuilder content = new StringBuilder();
        String line;
        while ((line = in.readLine()) != null) content.append(line);
        in.close();
        con.disconnect();

        // Debug: print raw API response
        System.out.println("Response Content: " + content);

        // Handle errors from Veriphone API
        if (status != 200) {
            resp.setStatus(HttpServletResponse.SC_BAD_GATEWAY);
            resp.getWriter().write("{\"error\": \"Failed to get response from Veriphone.\"}");
            return;
        }

        // Parse the JSON response
        JSONObject json;
        try {
            json = new JSONObject(content.toString());
        } catch (Exception e) {
            e.printStackTrace(); // Log parsing error
            resp.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            resp.getWriter().write("{\"error\": \"Malformed JSON received from API.\"}");
            return;
        }

        // Extract fields from JSON
        boolean phoneValid = json.optBoolean("phone_valid", false);
        String country = json.optString("country", "N/A");
        String carrier = json.optString("carrier", "N/A");
        String phoneType = json.optString("phone_type", "unknown");

        // Log the verification result to MongoDB
        try (MongoClient mongoClient = createMongoClient()) {
            MongoDatabase database = mongoClient.getDatabase(DB_NAME);
            MongoCollection<Document> collection = database.getCollection(COLLECTION_NAME);

            // Create a log document
            Document logEntry = new Document()
                    .append("timestamp", new Date())
                    .append("phone", phone)
                    .append("valid", phoneValid)
                    .append("country", country)
                    .append("carrier", carrier)
                    .append("phone_type", phoneType)
                    .append("source", "Android");

            collection.insertOne(logEntry);
        }

        // Respond with verification result in JSON
        resp.setContentType("application/json");
        resp.getWriter().write(new JSONObject()
                .put("phone", phone)
                .put("valid", phoneValid)
                .toString());
    }

    // Create a MongoDB client using specified settings and API version
    private MongoClient createMongoClient() {
        ServerApi serverApi = ServerApi.builder()
                .version(ServerApiVersion.V1)
                .build();

        MongoClientSettings settings = MongoClientSettings.builder()
                .applyConnectionString(new ConnectionString(MONGO_URI))
                .serverApi(serverApi)
                .build();

        return MongoClients.create(settings);
    }
}
