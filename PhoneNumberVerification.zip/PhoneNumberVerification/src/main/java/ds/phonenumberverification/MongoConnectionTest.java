// Kumar Amartya
// aamartya
package ds.phonenumberverification;

import com.mongodb.ConnectionString;
import com.mongodb.MongoClientSettings;
import com.mongodb.MongoException;
import com.mongodb.ServerApi;
import com.mongodb.ServerApiVersion;
import com.mongodb.client.*;
import org.bson.Document;

import java.util.Date;

public class MongoConnectionTest {
    public static void main(String[] args) {
        // Connection string to MongoDB Atlas cluster
        String connectionString = "mongodb+srv://aamartya:cmumism@androidproject.l70o0.mongodb.net/?retryWrites=true&w=majority&appName=AndroidProject";

        // Define the server API version to use (V1)
        ServerApi serverApi = ServerApi.builder()
                .version(ServerApiVersion.V1)
                .build();

        // Build the MongoClient settings using the connection string and server API
        MongoClientSettings settings = MongoClientSettings.builder()
                .applyConnectionString(new ConnectionString(connectionString))
                .serverApi(serverApi)
                .build();

        // Use try-with-resources to ensure the MongoClient is closed properly
        try (MongoClient mongoClient = MongoClients.create(settings)) {
            // Access the 'phone' database
            MongoDatabase database = mongoClient.getDatabase("phone");

            // Get the 'phonelogs' collection
            MongoCollection<Document> collection = database.getCollection("phonelogs");

            // Create a test document with mock phone verification data
            Document testLog = new Document()
                    .append("timestamp", new Date())
                    .append("phone", "+1234567890")
                    .append("valid", true)
                    .append("country", "Testland")
                    .append("carrier", "TestCarrier")
                    .append("source", "ConnectionTest");

            // Insert the test document into the collection
            collection.insertOne(testLog);
            System.out.println("Test log inserted!");

            // Retrieve and print all documents in the 'phonelogs' collection
            FindIterable<Document> logs = collection.find();
            System.out.println("\n📋 All logs in 'phonelogs' collection:");
            for (Document doc : logs) {
                System.out.println(doc.toJson());
            }

        } catch (MongoException e) {
            // Handle any exceptions related to MongoDB operations
            System.out.println("Failed to connect or interact with MongoDB:");
            e.printStackTrace();
        }
    }
}
