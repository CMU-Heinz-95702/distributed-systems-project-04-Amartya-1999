// Kumar Amartya
// aamartya
package ds.phonenumberverification;

import com.mongodb.ConnectionString;
import com.mongodb.MongoClientSettings;
import com.mongodb.ServerApi;
import com.mongodb.ServerApiVersion;
import com.mongodb.client.*;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import org.bson.Document;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

@WebServlet("/view-logs")
public class ViewLogsServlet extends HttpServlet {

    // MongoDB connection configuration
    private final String MONGO_URI = "mongodb+srv://aamartya:cmumism@androidproject.l70o0.mongodb.net/?retryWrites=true&w=majority&appName=AndroidProject";
    private final String DB_NAME = "phone";
    private final String COLLECTION_NAME = "phonelogs";

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        // List to store retrieved documents
        List<Document> logs = new ArrayList<>();

        // Establish MongoDB connection and retrieve all documents from collection
        try (MongoClient mongoClient = createMongoClient()) {
            MongoDatabase database = mongoClient.getDatabase(DB_NAME);
            MongoCollection<Document> collection = database.getCollection(COLLECTION_NAME);
            collection.find().into(logs); // Fetch all documents into the list
        }

        // Attach logs to the request and forward to JSP for rendering
        req.setAttribute("logs", logs);
        req.getRequestDispatcher("/dashboard.jsp").forward(req, resp);
    }

    // Helper method to create a MongoDB client with specified settings
    private MongoClient createMongoClient() {
        ServerApi serverApi = ServerApi.builder()
                .version(ServerApiVersion.V1)
                .build();

        MongoClientSettings settings = MongoClientSettings.builder()
                .applyConnectionString(new ConnectionString(MONGO_URI))
                .serverApi(serverApi)
                .build();

        return MongoClients.create(settings);
    }
}
