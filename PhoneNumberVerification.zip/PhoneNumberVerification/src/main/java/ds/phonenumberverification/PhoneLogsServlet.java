// Kumar Amartya
// aamartya

package ds.phonenumberverification;

import com.mongodb.client.*;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import org.bson.Document;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.*;

@WebServlet("/phone-logs")
public class PhoneLogsServlet extends HttpServlet {

    // Create a MongoClient instance to connect to MongoDB Atlas
    private final MongoClient mongoClient = MongoClients.create(
            "mongodb+srv://aamartya:cmumism@androidproject.l70o0.mongodb.net/phone?retryWrites=true&w=majority&appName=AndroidProject"
    );

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        // Access the 'phone' database and the 'phonelogs' collection
        MongoDatabase db = mongoClient.getDatabase("phone");
        MongoCollection<Document> logs = db.getCollection("phonelogs");

        // Fetch all logs into a list
        List<Document> allLogs = logs.find().into(new ArrayList<>());
        int total = allLogs.size(); // Total verifications
        int validCount = 0; // Counter for valid phone numbers
        Map<String, Integer> countryCounts = new HashMap<>(); // Map to track country-wise counts

        // Analyze logs to count valid entries and occurrences by country
        for (Document log : allLogs) {
            if (log.getBoolean("valid", false)) validCount++;
            String country = log.getString("country");
            if (country != null) {
                countryCounts.put(country, countryCounts.getOrDefault(country, 0) + 1);
            }
        }

        // Sort countries by frequency to get the top 3
        List<Map.Entry<String, Integer>> topCountries = new ArrayList<>(countryCounts.entrySet());
        Collections.sort(topCountries, new Comparator<Map.Entry<String, Integer>>() {
            @Override
            public int compare(Map.Entry<String, Integer> a, Map.Entry<String, Integer> b) {
                return b.getValue() - a.getValue();
            }
        });
        if (topCountries.size() > 3) {
            topCountries = topCountries.subList(0, 3);
        }

        // Set response content type to HTML
        resp.setContentType("text/html");
        PrintWriter out = resp.getWriter();

        // HTML structure and styling
        out.println("<html><head><title>📱 Phone Verifications</title>");
        out.println("<style>");
        out.println("body { font-family: Arial, sans-serif; background: #f2f2f2; padding: 30px; }");
        out.println("h1, h3 { color: #333; }");
        out.println("table { width: 100%; border-collapse: collapse; background: #fff; margin-top: 20px; }");
        out.println("th, td { border: 1px solid #ccc; padding: 10px; text-align: left; }");
        out.println("th { background: #e0e0e0; }");
        out.println(".badge-true { background: #4CAF50; color: white; padding: 3px 8px; border-radius: 4px; }");
        out.println(".badge-false { background: #f44336; color: white; padding: 3px 8px; border-radius: 4px; }");
        out.println(".highlight { background: #fffde7; padding: 15px; border: 1px solid #ffe082; border-radius: 6px; margin-bottom: 20px; }");
        out.println("</style></head><body>");

        // Dashboard header and summary section
        out.println("<h1>📊 Phone Number Lookup Dashboard</h1>");
        out.println("<div class='highlight'>");
        out.println("<p><strong>Total Verifications:</strong> " + total + "</p>");
        out.println("<p><strong>Valid:</strong> " + validCount + " | <strong>Invalid:</strong> " + (total - validCount) + "</p>");
        out.println("<p><strong>Top Countries:</strong></p><ul>");
        for (Map.Entry<String, Integer> entry : topCountries) {
            out.println("<li>" + escape(entry.getKey()) + " (" + entry.getValue() + ")</li>");
        }
        out.println("</ul></div>");

        // Log entries table
        out.println("<table><tr><th>Phone</th><th>Valid</th><th>Country</th><th>Carrier</th><th>Type</th><th>Timestamp</th></tr>");
        for (Document log : allLogs) {
            String phone = log.getString("phone");
            boolean valid = log.getBoolean("valid", false);
            String country = log.getString("country");
            String carrier = log.getString("carrier");
            String ts = log.getDate("timestamp") != null ? log.getDate("timestamp").toString() : "—";
            String type = log.getString("phone_type");

            // Display each log row with proper formatting
            out.printf("<tr><td>%s</td><td><span class='%s'>%s</span></td><td>%s</td><td>%s</td><td>%s</td><td>%s</td></tr>",
                    escape(phone),
                    valid ? "badge-true" : "badge-false",
                    valid ? "Yes" : "No",
                    escape(country),
                    escape(carrier),
                    escape(type),
                    escape(ts)
            );
        }

        out.println("</table></body></html>");
    }

    // Escape method to prevent HTML injection in user-supplied strings
    private String escape(String s) {
        return s == null ? "" : s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;");
    }
}
